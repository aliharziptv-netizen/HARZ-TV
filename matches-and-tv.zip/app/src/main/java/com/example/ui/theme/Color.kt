package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SophisticatedBg = Color(0xFF1A1C1E)
val SophisticatedCard = Color(0xFF2F3033)
val SophisticatedCardAlt = Color(0xFF3D4758)
val SophisticatedPrimary = Color(0xFF004785)
val SophisticatedAccent = Color(0xFFD1E4FF)
val SophisticatedOnPrimary = Color(0xFF00315C)
val SophisticatedRed = Color(0xFFBA1A1A)
val SophisticatedText = Color(0xFFE2E2E6)
val SophisticatedSecondaryText = Color(0xFFC4C6CF)

// Standard Jetpack Compose palette fallbacks
val Purple80 = Color(0xFFD1E4FF)
val PurpleGrey80 = Color(0xFF3D4758)
val Pink80 = Color(0xFFBA1A1A)

val Purple40 = Color(0xFF004785)
val PurpleGrey40 = Color(0xFF2F3033)
val Pink40 = Color(0xFFBA1A1A)

