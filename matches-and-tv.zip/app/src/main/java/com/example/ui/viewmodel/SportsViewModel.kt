package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.model.Category
import com.example.data.model.Channel
import com.example.data.model.Match
import com.example.data.repository.SportsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SportsViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: SportsRepository

    val matchesState: StateFlow<List<Match>>
    val channelsState: StateFlow<List<Channel>>
    val categoriesState: StateFlow<List<Category>>

    // Stream playback state
    private val _currentPlayingTitle = MutableStateFlow<String>("")
    val currentPlayingTitle: StateFlow<String> = _currentPlayingTitle.asStateFlow()

    private val _currentPlayingUrl = MutableStateFlow<String>("")
    val currentPlayingUrl: StateFlow<String> = _currentPlayingUrl.asStateFlow()

    private val _currentPlayingType = MutableStateFlow<String>("") // "MATCH" or "CHANNEL"
    val currentPlayingType: StateFlow<String> = _currentPlayingType.asStateFlow()

    init {
        val database = AppDatabase.getDatabase(application)
        repository = SportsRepository(database.sportsDao())

        matchesState = repository.allMatches.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        channelsState = repository.allChannels.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        categoriesState = repository.allCategories.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        // Prepopulate with rich sample data if DB is empty
        viewModelScope.launch {
            checkAndPrepopulateData()
        }
    }

    private suspend fun checkAndPrepopulateData() {
        // Wait for first flow emission to see if we have items
        val currentCategories = repository.allCategories.first()
        val currentMatches = repository.allMatches.first()
        val currentChannels = repository.allChannels.first()

        if (currentCategories.isEmpty() && currentMatches.isEmpty() && currentChannels.isEmpty()) {
            // Prepopulate Categories
            val defaultCategories = listOf(
                Category(name = "الدوري الإسباني", type = "MATCH"),
                Category(name = "الدوري الإنجليزي", type = "MATCH"),
                Category(name = "دوري أبطال أوروبا", type = "MATCH"),
                Category(name = "الدوري السعودي", type = "MATCH"),
                Category(name = "الدوري المصري", type = "MATCH"),
                Category(name = "قنوات رياضية", type = "CHANNEL"),
                Category(name = "قنوات ترفيهية", type = "CHANNEL"),
                Category(name = "قنوات إخبارية", type = "CHANNEL")
            )
            for (cat in defaultCategories) {
                repository.insertCategory(cat)
            }

            // Prepopulate Channels
            val defaultChannels = listOf(
                Channel(
                    name = "beIN Sports HD 1",
                    logoUrl = "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=400",
                    streamUrl = "https://assets.mixkit.co/videos/preview/mixkit-player-kicking-a-football-in-a-stadium-11728-large.mp4",
                    category = "قنوات رياضية"
                ),
                Channel(
                    name = "beIN Sports HD 2",
                    logoUrl = "https://images.unsplash.com/photo-1541252260730-0412e8e2108e?w=400",
                    streamUrl = "https://assets.mixkit.co/videos/preview/mixkit-soccer-ball-hit-the-goal-net-at-sunset-40502-large.mp4",
                    category = "قنوات رياضية"
                ),
                Channel(
                    name = "SSC Sports HD 1",
                    logoUrl = "https://images.unsplash.com/photo-1518063319789-7217e6706b04?w=400",
                    streamUrl = "https://assets.mixkit.co/videos/preview/mixkit-football-kicked-by-player-into-goal-40500-large.mp4",
                    category = "قنوات رياضية"
                ),
                Channel(
                    name = "Al Kass HD One",
                    logoUrl = "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=400",
                    streamUrl = "https://assets.mixkit.co/videos/preview/mixkit-player-running-on-football-field-40504-large.mp4",
                    category = "قنوات رياضية"
                ),
                Channel(
                    name = "MBC 1",
                    logoUrl = "https://images.unsplash.com/photo-1594909122845-11baa439b7bf?w=400",
                    streamUrl = "https://assets.mixkit.co/videos/preview/mixkit-clapperboard-on-a-production-set-33411-large.mp4",
                    category = "قنوات ترفيهية"
                ),
                Channel(
                    name = "Al Jazeera News",
                    logoUrl = "https://images.unsplash.com/photo-1504711434969-e33886168f5c?w=400",
                    streamUrl = "https://assets.mixkit.co/videos/preview/mixkit-concept-of-digital-global-news-on-tablet-screen-42358-large.mp4",
                    category = "قنوات إخبارية"
                )
            )
            for (ch in defaultChannels) {
                repository.insertChannel(ch)
            }

            // Prepopulate Matches
            val defaultMatches = listOf(
                Match(
                    homeTeam = "ريال مدريد",
                    awayTeam = "برشلونة",
                    homeTeamLogo = "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=400", // Placeholder team logos
                    awayTeamLogo = "https://images.unsplash.com/photo-1541252260730-0412e8e2108e?w=400",
                    matchTime = "21:45",
                    matchDate = "اليوم",
                    leagueName = "الدوري الإسباني",
                    status = "LIVE",
                    channelName = "beIN Sports HD 1",
                    streamUrl = "https://assets.mixkit.co/videos/preview/mixkit-player-kicking-a-football-in-a-stadium-11728-large.mp4",
                    homeScore = 2,
                    awayScore = 1,
                    commentator = "عصام الشوالي"
                ),
                Match(
                    homeTeam = "مانشستر سيتي",
                    awayTeam = "أرسنال",
                    homeTeamLogo = "https://images.unsplash.com/photo-1518063319789-7217e6706b04?w=400",
                    awayTeamLogo = "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=400",
                    matchTime = "18:30",
                    matchDate = "اليوم",
                    leagueName = "الدوري الإنجليزي",
                    status = "NOT_STARTED",
                    channelName = "beIN Sports HD 2",
                    streamUrl = "https://assets.mixkit.co/videos/preview/mixkit-soccer-ball-hit-the-goal-net-at-sunset-40502-large.mp4",
                    commentator = "حفيظ دراجي"
                ),
                Match(
                    homeTeam = "الهلال",
                    awayTeam = "النصر",
                    homeTeamLogo = "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=400",
                    awayTeamLogo = "https://images.unsplash.com/photo-1518063319789-7217e6706b04?w=400",
                    matchTime = "21:00",
                    matchDate = "غداً",
                    leagueName = "الدوري السعودي",
                    status = "NOT_STARTED",
                    channelName = "SSC Sports HD 1",
                    streamUrl = "https://assets.mixkit.co/videos/preview/mixkit-football-kicked-by-player-into-goal-40500-large.mp4",
                    commentator = "فهد العتيبي"
                ),
                Match(
                    homeTeam = "الأهلي",
                    awayTeam = "الزمالك",
                    homeTeamLogo = "https://images.unsplash.com/photo-1541252260730-0412e8e2108e?w=400",
                    awayTeamLogo = "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=400",
                    matchTime = "20:00",
                    matchDate = "أمس",
                    leagueName = "الدوري المصري",
                    status = "FINISHED",
                    channelName = "Al Kass HD One",
                    streamUrl = "https://assets.mixkit.co/videos/preview/mixkit-player-running-on-football-field-40504-large.mp4",
                    homeScore = 3,
                    awayScore = 1,
                    commentator = "خليل البلوشي"
                )
            )
            for (match in defaultMatches) {
                repository.insertMatch(match)
            }
        }
    }

    // Play stream action
    fun playStream(title: String, url: String, type: String) {
        _currentPlayingTitle.value = title
        _currentPlayingUrl.value = url
        _currentPlayingType.value = type
    }

    fun stopStream() {
        _currentPlayingTitle.value = ""
        _currentPlayingUrl.value = ""
        _currentPlayingType.value = ""
    }

    // Matches management
    fun saveMatch(match: Match) {
        viewModelScope.launch {
            repository.insertMatch(match)
        }
    }

    fun deleteMatch(id: Int) {
        viewModelScope.launch {
            repository.deleteMatchById(id)
            if (_currentPlayingUrl.value != "" && _currentPlayingType.value == "MATCH") {
                stopStream()
            }
        }
    }

    // Channels management
    fun saveChannel(channel: Channel) {
        viewModelScope.launch {
            repository.insertChannel(channel)
        }
    }

    fun deleteChannel(id: Int) {
        viewModelScope.launch {
            repository.deleteChannelById(id)
            if (_currentPlayingUrl.value != "" && _currentPlayingType.value == "CHANNEL") {
                stopStream()
            }
        }
    }

    // Categories management
    fun saveCategory(category: Category) {
        viewModelScope.launch {
            repository.insertCategory(category)
        }
    }

    fun deleteCategory(id: Int) {
        viewModelScope.launch {
            repository.deleteCategoryById(id)
        }
    }
}
