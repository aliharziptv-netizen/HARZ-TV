package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.Category
import com.example.data.model.Channel
import com.example.data.model.Match
import com.example.ui.components.StreamPlayer
import com.example.ui.viewmodel.SportsViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainDashboard(
    viewModel: SportsViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val matches by viewModel.matchesState.collectAsState()
    val channels by viewModel.channelsState.collectAsState()
    val categories by viewModel.categoriesState.collectAsState()

    val currentPlayingTitle by viewModel.currentPlayingTitle.collectAsState()
    val currentPlayingUrl by viewModel.currentPlayingUrl.collectAsState()

    var selectedTab by remember { mutableStateOf(0) } // 0: Matches, 1: Channels, 2: Admin Panel

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            Column {
                // Header Bar
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SophisticatedBg)
                        .padding(horizontal = 16.dp, vertical = 14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        IconButton(
                            onClick = {
                                showToast(context, "تطبيق كورة تي في - تم التحديث بنجاح")
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "تحديث",
                                tint = SophisticatedText
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "KORA TV | كورة",
                                color = SophisticatedText,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.Default.SportsSoccer,
                                contentDescription = "كرة القدم",
                                tint = SophisticatedAccent,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        IconButton(
                            onClick = {
                                selectedTab = 2 // Direct to admin panel
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "الإعدادات ولوحة التحكم",
                                tint = if (selectedTab == 2) SophisticatedAccent else SophisticatedText
                            )
                        }
                    }
                }

                // Streaming Player (Always anchored when active)
                AnimatedVisibility(
                    visible = currentPlayingUrl.isNotEmpty(),
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    StreamPlayer(
                        title = currentPlayingTitle,
                        streamUrl = currentPlayingUrl,
                        onClose = { viewModel.stopStream() }
                    )
                }
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = SophisticatedBg,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.SportsSoccer,
                            contentDescription = "المباريات"
                        )
                    },
                    label = { Text("المباريات") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = SophisticatedOnPrimary,
                        selectedTextColor = SophisticatedAccent,
                        indicatorColor = SophisticatedAccent,
                        unselectedIconColor = SophisticatedSecondaryText,
                        unselectedTextColor = SophisticatedSecondaryText
                    )
                )

                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.LiveTv,
                            contentDescription = "القنوات"
                        )
                    },
                    label = { Text("القنوات التلفزيونية") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = SophisticatedOnPrimary,
                        selectedTextColor = SophisticatedAccent,
                        indicatorColor = SophisticatedAccent,
                        unselectedIconColor = SophisticatedSecondaryText,
                        unselectedTextColor = SophisticatedSecondaryText
                    )
                )

                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "لوحة التحكم"
                        )
                    },
                    label = { Text("لوحة التحكم") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = SophisticatedOnPrimary,
                        selectedTextColor = SophisticatedAccent,
                        indicatorColor = SophisticatedAccent,
                        unselectedIconColor = SophisticatedSecondaryText,
                        unselectedTextColor = SophisticatedSecondaryText
                    )
                )
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                0 -> MatchesScreen(
                    matches = matches,
                    onPlayMatch = { match ->
                        viewModel.playStream(
                            title = "${match.homeTeam} × ${match.awayTeam}",
                            url = match.streamUrl,
                            type = "MATCH"
                        )
                    }
                )
                1 -> TVChannelsScreen(
                    channels = channels,
                    categories = categories.filter { it.type == "CHANNEL" },
                    onPlayChannel = { channel ->
                        viewModel.playStream(
                            title = channel.name,
                            url = channel.streamUrl,
                            type = "CHANNEL"
                        )
                    }
                )
                2 -> AdminPanelScreen(
                    viewModel = viewModel,
                    matches = matches,
                    channels = channels,
                    categories = categories
                )
            }
        }
    }
}

// -----------------------------------------
// 1. MATCHES SCREEN
// -----------------------------------------
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MatchesScreen(
    matches: List<Match>,
    onPlayMatch: (Match) -> Unit
) {
    var filterStatus by remember { mutableStateOf("ALL") } // "ALL", "LIVE", "NOT_STARTED", "FINISHED"

    val filteredMatches = when (filterStatus) {
        "ALL" -> matches
        else -> matches.filter { it.status == filterStatus }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
    ) {
        // Horizontal Filters
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val filters = listOf(
                Triple("الكل", "ALL", null),
                Triple("مباشر 🔴", "LIVE", SophisticatedRed),
                Triple("قادمة", "NOT_STARTED", SophisticatedAccent),
                Triple("منتهية", "FINISHED", SophisticatedSecondaryText)
            )

            filters.forEach { (label, statusValue, color) ->
                val isSelected = filterStatus == statusValue
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            if (isSelected) SophisticatedAccent else SophisticatedCard
                        )
                        .clickable { filterStatus = statusValue }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        color = if (isSelected) SophisticatedOnPrimary else SophisticatedText,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        if (filteredMatches.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.SportsSoccer,
                        contentDescription = "لا يوجد مباريات",
                        tint = Color.Gray,
                        modifier = Modifier.size(54.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "لا توجد مباريات حالياً في هذا التصنيف",
                        color = Color.LightGray,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredMatches) { match ->
                    MatchCard(match = match, onPlayMatch = onPlayMatch)
                }
            }
        }
    }
}

@Composable
fun MatchCard(
    match: Match,
    onPlayMatch: (Match) -> Unit
) {
    val isLive = match.status == "LIVE"
    val containerColor = if (isLive) SophisticatedPrimary else SophisticatedCard
    val contentColor = if (isLive) SophisticatedAccent else SophisticatedText
    val cardShape = if (isLive) RoundedCornerShape(28.dp) else RoundedCornerShape(16.dp)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("match_card_${match.id}"),
        colors = CardDefaults.cardColors(
            containerColor = containerColor,
            contentColor = contentColor
        ),
        shape = cardShape,
        elevation = CardDefaults.cardElevation(defaultElevation = if (isLive) 8.dp else 4.dp)
    ) {
        Column(
            modifier = Modifier.padding(if (isLive) 20.dp else 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // League and Channel Metadata Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // League Name Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isLive) Color.White.copy(alpha = 0.15f) else SophisticatedCardAlt)
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = match.leagueName,
                        color = if (isLive) SophisticatedAccent else SophisticatedAccent,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Match Status Indicator
                when (match.status) {
                    "LIVE" -> {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(SophisticatedRed)
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(Color.White)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "بث مباشر",
                                color = Color.White,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    "FINISHED" -> {
                        Text(
                            text = "منتهية",
                            color = SophisticatedSecondaryText,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(SophisticatedCardAlt)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                    else -> {
                        Text(
                            text = match.matchTime,
                            color = SophisticatedAccent,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(SophisticatedCardAlt)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Teams VS Score Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                // Home Team
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.weight(1f)
                ) {
                    TeamLogoAndName(
                        logoUrl = match.homeTeamLogo,
                        name = match.homeTeam,
                        textColor = contentColor
                    )
                }

                // VS / Score Central area
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(horizontal = 10.dp)
                ) {
                    if (match.status == "LIVE" || match.status == "FINISHED") {
                        Text(
                            text = "${match.homeScore}  -  ${match.awayScore}",
                            color = if (isLive) Color.White else SophisticatedText,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Black,
                            fontSize = 30.sp
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.Black.copy(alpha = 0.25f))
                                .padding(horizontal = 14.dp, vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "VS",
                                color = SophisticatedSecondaryText,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = match.matchDate,
                        color = if (isLive) SophisticatedAccent.copy(alpha = 0.7f) else SophisticatedSecondaryText,
                        style = MaterialTheme.typography.labelSmall
                    )
                }

                // Away Team
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.weight(1f)
                ) {
                    TeamLogoAndName(
                        logoUrl = match.awayTeamLogo,
                        name = match.awayTeam,
                        textColor = contentColor
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Extra Info (Commentator, TV station)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color.Black.copy(alpha = 0.15f))
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                Text(
                    text = "🎤 المعلق: " + match.commentator.ifEmpty { "غير محدد" },
                    color = if (isLive) SophisticatedAccent.copy(alpha = 0.8f) else SophisticatedSecondaryText,
                    style = MaterialTheme.typography.labelSmall
                )
                Text(
                    text = "📺 القناة: " + match.channelName.ifEmpty { "غير معروفة" },
                    color = if (isLive) SophisticatedAccent.copy(alpha = 0.8f) else SophisticatedSecondaryText,
                    style = MaterialTheme.typography.labelSmall
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Play / Watch Button
            val buttonContainerColor = if (isLive) SophisticatedAccent else SophisticatedCardAlt
            val buttonContentColor = if (isLive) SophisticatedOnPrimary else SophisticatedAccent

            Button(
                onClick = { onPlayMatch(match) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = buttonContainerColor,
                    contentColor = buttonContentColor
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("watch_match_btn_${match.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "مشاهدة",
                    tint = buttonContentColor
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (match.status == "LIVE") "شاهد البث المباشر الآن" else "تغطية وملخصات المباراة",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

@Composable
fun TeamLogoAndName(
    logoUrl: String,
    name: String,
    textColor: Color = Color.White
) {
    if (logoUrl.isNotEmpty()) {
        AsyncImage(
            model = logoUrl,
            contentDescription = name,
            modifier = Modifier
                .size(54.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.12f)),
            contentScale = ContentScale.Crop
        )
    } else {
        // Fallback Initial Card
        Box(
            modifier = Modifier
                .size(54.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = name.take(2),
                color = textColor,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        }
    }
    Spacer(modifier = Modifier.height(6.dp))
    Text(
        text = name,
        color = textColor,
        fontWeight = FontWeight.Bold,
        style = MaterialTheme.typography.bodyMedium,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        textAlign = TextAlign.Center
    )
}


// -----------------------------------------
// 2. TV CHANNELS SCREEN
// -----------------------------------------
@Composable
fun TVChannelsScreen(
    channels: List<Channel>,
    categories: List<Category>,
    onPlayChannel: (Channel) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("ALL") }

    val filteredChannels = channels.filter { channel ->
        val matchesSearch = channel.name.contains(searchQuery, ignoreCase = true)
        val matchesCategory = selectedCategory == "ALL" || channel.category == selectedCategory
        matchesSearch && matchesCategory
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
    ) {
        // Search bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("بحث عن قناة تليفزيونية...", color = SophisticatedSecondaryText) },
            leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = "بحث", tint = SophisticatedSecondaryText) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = SophisticatedText,
                unfocusedTextColor = SophisticatedText,
                focusedContainerColor = SophisticatedCardAlt,
                unfocusedContainerColor = SophisticatedCard,
                focusedBorderColor = SophisticatedAccent,
                unfocusedBorderColor = SophisticatedCardAlt
            ),
            singleLine = true
        )

        // Dynamic categories chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
                .verticalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Category "All"
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (selectedCategory == "ALL") SophisticatedAccent else SophisticatedCard)
                    .clickable { selectedCategory = "ALL" }
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "الكل",
                    color = if (selectedCategory == "ALL") SophisticatedOnPrimary else SophisticatedText,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            categories.forEach { category ->
                val isSelected = selectedCategory == category.name
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (isSelected) SophisticatedAccent else SophisticatedCard)
                        .clickable { selectedCategory = category.name }
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = category.name,
                        color = if (isSelected) SophisticatedOnPrimary else SophisticatedText,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        if (filteredChannels.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Tv,
                        contentDescription = "لا يوجد قنوات",
                        tint = SophisticatedSecondaryText,
                        modifier = Modifier.size(54.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "عذراً، لم نجد قنوات تلفزيونية تطابق البحث",
                        color = SophisticatedSecondaryText,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredChannels) { channel ->
                    ChannelCard(channel = channel, onPlayChannel = onPlayChannel)
                }
            }
        }
    }
}

@Composable
fun ChannelCard(
    channel: Channel,
    onPlayChannel: (Channel) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onPlayChannel(channel) }
            .testTag("channel_card_${channel.id}"),
        colors = CardDefaults.cardColors(
            containerColor = SophisticatedCard,
            contentColor = SophisticatedText
        ),
        shape = RoundedCornerShape(14.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Logo Image
            if (channel.logoUrl.isNotEmpty()) {
                AsyncImage(
                    model = channel.logoUrl,
                    contentDescription = channel.name,
                    modifier = Modifier
                        .size(64.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(SophisticatedCardAlt),
                    contentScale = ContentScale.Crop
                )
            } else {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(SophisticatedCardAlt),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Tv,
                        contentDescription = "قناة",
                        tint = SophisticatedAccent,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = channel.name,
                color = SophisticatedText,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.bodyMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = channel.category,
                color = SophisticatedAccent,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.labelSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(SophisticatedCardAlt)
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SophisticatedAccent.copy(alpha = 0.15f))
                    .padding(vertical = 5.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "بث",
                    tint = SophisticatedAccent,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "بث مباشر",
                    color = SophisticatedAccent,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }
    }
}


// -----------------------------------------
// 3. ADMIN PANEL SCREEN
// -----------------------------------------
@Composable
fun AdminPanelScreen(
    viewModel: SportsViewModel,
    matches: List<Match>,
    channels: List<Channel>,
    categories: List<Category>
) {
    val context = LocalContext.current
    var subTab by remember { mutableStateOf(0) } // 0: Matches, 1: Channels, 2: Categories
    var isAdminVerified by remember { mutableStateOf(false) } // Default to false, secure authentication
    var passwordInput by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var isError by remember { mutableStateOf(false) }

    if (!isAdminVerified) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth(0.95f)
                    .wrapContentWidth(Alignment.CenterHorizontally),
                colors = CardDefaults.cardColors(
                    containerColor = SophisticatedCard,
                    contentColor = SophisticatedText
                ),
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .padding(24.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(SophisticatedAccent.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "قفل",
                            tint = SophisticatedAccent,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "تسجيل دخول المشرف",
                        color = SophisticatedText,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "يرجى إدخال مفتاح المرور للوصول إلى لوحة التحكم",
                        color = SophisticatedSecondaryText,
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    OutlinedTextField(
                        value = passwordInput,
                        onValueChange = {
                            passwordInput = it
                            isError = false
                        },
                        placeholder = { Text("أدخل مفتاح المرور الخاص بك...", color = SophisticatedSecondaryText) },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "مفتاح المرور",
                                tint = if (isError) SophisticatedRed else SophisticatedSecondaryText
                            )
                        },
                        trailingIcon = {
                            val icon = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(imageVector = icon, contentDescription = "إظهار/إخفاء مفتاح المرور", tint = SophisticatedSecondaryText)
                            }
                        },
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        isError = isError,
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("admin_login_password_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = SophisticatedText,
                            unfocusedTextColor = SophisticatedText,
                            focusedContainerColor = SophisticatedCardAlt,
                            unfocusedContainerColor = SophisticatedBg,
                            focusedBorderColor = if (isError) SophisticatedRed else SophisticatedAccent,
                            unfocusedBorderColor = if (isError) SophisticatedRed else SophisticatedCardAlt,
                            errorBorderColor = SophisticatedRed
                        )
                    )

                    if (isError) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "مفتاح المرور غير صحيح! حاول مرة أخرى.",
                            color = SophisticatedRed,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.align(Alignment.End)
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = {
                            if (passwordInput == "HHARZ11") {
                                isAdminVerified = true
                                isError = false
                                showToast(context, "تم تسجيل الدخول بنجاح كمسؤول")
                            } else {
                                isError = true
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SophisticatedAccent,
                            contentColor = SophisticatedOnPrimary
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("admin_login_submit_btn")
                    ) {
                        Text(
                            text = "تسجيل الدخول",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        }
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
        ) {
            Text(
                text = "لوحة تحكم المشرف لإدارة المحتوى",
                color = SophisticatedText,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 12.dp),
                textAlign = TextAlign.Right
            )

            // Sub Tab selector
            TabRow(
                selectedTabIndex = subTab,
                containerColor = SophisticatedCard,
                contentColor = SophisticatedText,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[subTab]),
                        color = SophisticatedAccent
                    )
                },
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .padding(bottom = 12.dp)
            ) {
                Tab(
                    selected = subTab == 0,
                    onClick = { subTab = 0 },
                    text = { Text("المباريات", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = subTab == 1,
                    onClick = { subTab = 1 },
                    text = { Text("القنوات", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = subTab == 2,
                    onClick = { subTab = 2 },
                    text = { Text("التصنيفات", fontWeight = FontWeight.Bold) }
                )
            }

            when (subTab) {
                0 -> ManageMatchesSubscreen(viewModel = viewModel, matches = matches)
                1 -> ManageChannelsSubscreen(viewModel = viewModel, channels = channels, categories = categories.filter { it.type == "CHANNEL" })
                2 -> ManageCategoriesSubscreen(viewModel = viewModel, categories = categories)
            }
        }
    }
}

// Sub components for Admin Panel
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManageMatchesSubscreen(
    viewModel: SportsViewModel,
    matches: List<Match>
) {
    val context = LocalContext.current

    // Form inputs state
    var editingMatchId by remember { mutableStateOf<Int?>(null) }
    var homeTeam by remember { mutableStateOf("") }
    var awayTeam by remember { mutableStateOf("") }
    var homeTeamLogo by remember { mutableStateOf("") }
    var awayTeamLogo by remember { mutableStateOf("") }
    var matchTime by remember { mutableStateOf("") }
    var matchDate by remember { mutableStateOf("") }
    var leagueName by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("LIVE") } // "NOT_STARTED", "LIVE", "FINISHED"
    var channelName by remember { mutableStateOf("") }
    var streamUrl by remember { mutableStateOf("") }
    var homeScore by remember { mutableStateOf("0") }
    var awayScore by remember { mutableStateOf("0") }
    var commentator by remember { mutableStateOf("") }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
    ) {
        // Form Section
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 14.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = if (editingMatchId == null) "إضافة مباراة جديدة" else "تعديل المباراة المحددة",
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(bottom = 10.dp)
                )

                OutlinedTextField(
                    value = homeTeam,
                    onValueChange = { homeTeam = it },
                    label = { Text("الفريق صاحب الأرض") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = awayTeam,
                    onValueChange = { awayTeam = it },
                    label = { Text("الفريق الضيف") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = homeTeamLogo,
                    onValueChange = { homeTeamLogo = it },
                    label = { Text("رابط شعار صاحب الأرض (صورة)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = awayTeamLogo,
                    onValueChange = { awayTeamLogo = it },
                    label = { Text("رابط شعار الضيف (صورة)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = matchTime,
                        onValueChange = { matchTime = it },
                        label = { Text("توقيت المباراة (مثال 20:45)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedTextField(
                        value = matchDate,
                        onValueChange = { matchDate = it },
                        label = { Text("تاريخ المباراة (اليوم/غداً)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = leagueName,
                        onValueChange = { leagueName = it },
                        label = { Text("اسم البطولة/الدوري") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedTextField(
                        value = commentator,
                        onValueChange = { commentator = it },
                        label = { Text("المعلق") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = channelName,
                    onValueChange = { channelName = it },
                    label = { Text("القناة الناقلة") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = streamUrl,
                    onValueChange = { streamUrl = it },
                    label = { Text("رابط البث المباشر (مقطع فيديو أو صفحة بث)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    // Status Dropdown selector
                    Box(modifier = Modifier.weight(1.5f)) {
                        var expanded by remember { mutableStateOf(false) }
                        val statuses = listOf(
                            "LIVE" to "مباشر 🔴",
                            "NOT_STARTED" to "قادمة 📅",
                            "FINISHED" to "منتهية 🏁"
                        )
                        val selectedLabel = statuses.find { it.first == status }?.second ?: status

                        ExposedDropdownMenuBox(
                            expanded = expanded,
                            onExpandedChange = { expanded = it }
                        ) {
                            OutlinedTextField(
                                value = selectedLabel,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("حالة المباراة") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                                modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth()
                            )
                            ExposedDropdownMenu(
                                expanded = expanded,
                                onDismissRequest = { expanded = false }
                            ) {
                                statuses.forEach { (valKey, valLabel) ->
                                    DropdownMenuItem(
                                        text = { Text(valLabel) },
                                        onClick = {
                                            status = valKey
                                            expanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    OutlinedTextField(
                        value = homeScore,
                        onValueChange = { homeScore = it },
                        label = { Text("أهداف الأرض") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    OutlinedTextField(
                        value = awayScore,
                        onValueChange = { awayScore = it },
                        label = { Text("أهداف الضيف") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    if (editingMatchId != null) {
                        OutlinedButton(
                            onClick = {
                                editingMatchId = null
                                homeTeam = ""
                                awayTeam = ""
                                homeTeamLogo = ""
                                awayTeamLogo = ""
                                matchTime = ""
                                matchDate = ""
                                leagueName = ""
                                status = "LIVE"
                                channelName = ""
                                streamUrl = ""
                                homeScore = "0"
                                awayScore = "0"
                                commentator = ""
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("إلغاء التعديل")
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                    }

                    Button(
                        onClick = {
                            if (homeTeam.isEmpty() || awayTeam.isEmpty()) {
                                showToast(context, "الرجاء كتابة أسماء الفرق أولاً!")
                                return@Button
                            }
                            val safeHomeScore = homeScore.toIntOrNull() ?: 0
                            val safeAwayScore = awayScore.toIntOrNull() ?: 0

                            val m = Match(
                                id = editingMatchId ?: 0,
                                homeTeam = homeTeam,
                                awayTeam = awayTeam,
                                homeTeamLogo = homeTeamLogo,
                                awayTeamLogo = awayTeamLogo,
                                matchTime = matchTime,
                                matchDate = matchDate,
                                leagueName = leagueName,
                                status = status,
                                channelName = channelName,
                                streamUrl = streamUrl,
                                homeScore = safeHomeScore,
                                awayScore = safeAwayScore,
                                commentator = commentator
                            )
                            viewModel.saveMatch(m)
                            showToast(context, "تم حفظ بيانات المباراة بنجاح")

                            // Clear Form
                            editingMatchId = null
                            homeTeam = ""
                            awayTeam = ""
                            homeTeamLogo = ""
                            awayTeamLogo = ""
                            matchTime = ""
                            matchDate = ""
                            leagueName = ""
                            status = "LIVE"
                            channelName = ""
                            streamUrl = ""
                            homeScore = "0"
                            awayScore = "0"
                            commentator = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier.weight(1.5f)
                    ) {
                        Text(if (editingMatchId == null) "إضافة المباراة الآن" else "تحديث تفاصيل المباراة", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // List of Matches to Manage
        Text(
            text = "المباريات المضافة حالياً",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(bottom = 10.dp)
        )

        matches.forEach { match ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF161F30))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${match.homeTeam} × ${match.awayTeam}",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "${match.leagueName} | ${match.matchDate} ${match.matchTime}",
                            color = Color.LightGray,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }

                    Row {
                        IconButton(
                            onClick = {
                                editingMatchId = match.id
                                homeTeam = match.homeTeam
                                awayTeam = match.awayTeam
                                homeTeamLogo = match.homeTeamLogo
                                awayTeamLogo = match.awayTeamLogo
                                matchTime = match.matchTime
                                matchDate = match.matchDate
                                leagueName = match.leagueName
                                status = match.status
                                channelName = match.channelName
                                streamUrl = match.streamUrl
                                homeScore = match.homeScore.toString()
                                awayScore = match.awayScore.toString()
                                commentator = match.commentator
                            }
                        ) {
                            Icon(imageVector = Icons.Default.Edit, contentDescription = "تعديل", tint = MaterialTheme.colorScheme.primary)
                        }

                        IconButton(
                            onClick = {
                                viewModel.deleteMatch(match.id)
                                showToast(context, "تم حذف المباراة بنجاح")
                            }
                        ) {
                            Icon(imageVector = Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManageChannelsSubscreen(
    viewModel: SportsViewModel,
    channels: List<Channel>,
    categories: List<Category>
) {
    val context = LocalContext.current

    var editingChannelId by remember { mutableStateOf<Int?>(null) }
    var name by remember { mutableStateOf("") }
    var logoUrl by remember { mutableStateOf("") }
    var streamUrl by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("قنوات رياضية") }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 14.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = if (editingChannelId == null) "إضافة قناة تليفزيونية" else "تعديل القناة التليفزيونية",
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(bottom = 10.dp)
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم القناة") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = logoUrl,
                    onValueChange = { logoUrl = it },
                    label = { Text("رابط شعار القناة (صورة)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = streamUrl,
                    onValueChange = { streamUrl = it },
                    label = { Text("رابط بث القناة (بث مباشر M3U8 أو صفحة ويب)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Category Selector
                Box(modifier = Modifier.fillMaxWidth()) {
                    var expanded by remember { mutableStateOf(false) }

                    ExposedDropdownMenuBox(
                        expanded = expanded,
                        onExpandedChange = { expanded = it }
                    ) {
                        OutlinedTextField(
                            value = category,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("تصنيف القناة") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                            modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth()
                        )
                        ExposedDropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false }
                        ) {
                            categories.forEach { cat ->
                                DropdownMenuItem(
                                    text = { Text(cat.name) },
                                    onClick = {
                                        category = cat.name
                                        expanded = false
                                    }
                                )
                            }
                            // Fallback default options
                            if (categories.isEmpty()) {
                                listOf("قنوات رياضية", "قنوات ترفيهية", "قنوات إخبارية").forEach { catName ->
                                    DropdownMenuItem(
                                        text = { Text(catName) },
                                        onClick = {
                                            category = catName
                                            expanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    if (editingChannelId != null) {
                        OutlinedButton(
                            onClick = {
                                editingChannelId = null
                                name = ""
                                logoUrl = ""
                                streamUrl = ""
                                category = "قنوات رياضية"
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("إلغاء التعديل")
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                    }

                    Button(
                        onClick = {
                            if (name.isEmpty() || streamUrl.isEmpty()) {
                                showToast(context, "الرجاء كتابة اسم القناة ورابط البث المباشر!")
                                return@Button
                            }

                            val ch = Channel(
                                id = editingChannelId ?: 0,
                                name = name,
                                logoUrl = logoUrl,
                                streamUrl = streamUrl,
                                category = category
                            )
                            viewModel.saveChannel(ch)
                            showToast(context, "تم حفظ بيانات القناة بنجاح")

                            // Clear Form
                            editingChannelId = null
                            name = ""
                            logoUrl = ""
                            streamUrl = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier.weight(1.5f)
                    ) {
                        Text(if (editingChannelId == null) "إضافة القناة الآن" else "تحديث بيانات القناة", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // List of Channels to Manage
        Text(
            text = "القنوات التلفزيونية المضافة حالياً",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(bottom = 10.dp)
        )

        channels.forEach { ch ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF161F30))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = ch.name,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = ch.category,
                            color = MaterialTheme.colorScheme.primary,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }

                    Row {
                        IconButton(
                            onClick = {
                                editingChannelId = ch.id
                                name = ch.name
                                logoUrl = ch.logoUrl
                                streamUrl = ch.streamUrl
                                category = ch.category
                            }
                        ) {
                            Icon(imageVector = Icons.Default.Edit, contentDescription = "تعديل", tint = MaterialTheme.colorScheme.primary)
                        }

                        IconButton(
                            onClick = {
                                viewModel.deleteChannel(ch.id)
                                showToast(context, "تم حذف القناة بنجاح")
                            }
                        ) {
                            Icon(imageVector = Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManageCategoriesSubscreen(
    viewModel: SportsViewModel,
    categories: List<Category>
) {
    val context = LocalContext.current

    var newCategoryName by remember { mutableStateOf("") }
    var categoryType by remember { mutableStateOf("MATCH") } // "MATCH" or "CHANNEL"

    Column(modifier = Modifier.fillMaxSize()) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 14.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "إضافة تصنيف جديد",
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(bottom = 10.dp)
                )

                OutlinedTextField(
                    value = newCategoryName,
                    onValueChange = { newCategoryName = it },
                    label = { Text("اسم التصنيف") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.weight(1f)) {
                        var expanded by remember { mutableStateOf(false) }
                        val types = listOf(
                            "MATCH" to "تصنيف مباريات",
                            "CHANNEL" to "تصنيف قنوات تلفزيون"
                        )
                        val selectedLabel = types.find { it.first == categoryType }?.second ?: categoryType

                        ExposedDropdownMenuBox(
                            expanded = expanded,
                            onExpandedChange = { expanded = it }
                        ) {
                            OutlinedTextField(
                                value = selectedLabel,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("نوع التصنيف") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                                modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth()
                            )
                            ExposedDropdownMenu(
                                expanded = expanded,
                                onDismissRequest = { expanded = false }
                            ) {
                                types.forEach { (valKey, valLabel) ->
                                    DropdownMenuItem(
                                        text = { Text(valLabel) },
                                        onClick = {
                                            categoryType = valKey
                                            expanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Button(
                        onClick = {
                            if (newCategoryName.isEmpty()) {
                                showToast(context, "الرجاء كتابة اسم التصنيف!")
                                return@Button
                            }

                            val cat = Category(
                                name = newCategoryName,
                                type = categoryType
                            )
                            viewModel.saveCategory(cat)
                            showToast(context, "تم حفظ التصنيف بنجاح")
                            newCategoryName = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier.height(54.dp)
                    ) {
                        Text("إضافة التصنيف", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // List of existing categories
        Text(
            text = "التصنيفات المضافة حالياً",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(bottom = 10.dp)
        )

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(categories) { cat ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF161F30))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = cat.name,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text(
                                text = if (cat.type == "MATCH") "نوع: مباريات" else "نوع: قنوات تلفزيونية",
                                color = Color.LightGray,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }

                        IconButton(
                            onClick = {
                                viewModel.deleteCategory(cat.id)
                                showToast(context, "تم حذف التصنيف بنجاح")
                            }
                        ) {
                            Icon(imageVector = Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red)
                        }
                    }
                }
            }
        }
    }
}

private var currentToast: Toast? = null

fun showToast(context: android.content.Context, message: String, duration: Int = Toast.LENGTH_SHORT) {
    currentToast?.cancel()
    currentToast = Toast.makeText(context.applicationContext, message, duration).apply {
        show()
    }
}

