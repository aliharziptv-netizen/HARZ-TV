package com.example.data.repository

import com.example.data.dao.SportsDao
import com.example.data.model.Match
import com.example.data.model.Channel
import com.example.data.model.Category
import kotlinx.coroutines.flow.Flow

class SportsRepository(private val sportsDao: SportsDao) {

    val allMatches: Flow<List<Match>> = sportsDao.getAllMatches()
    val allChannels: Flow<List<Channel>> = sportsDao.getAllChannels()
    val allCategories: Flow<List<Category>> = sportsDao.getAllCategories()

    suspend fun getMatchById(id: Int): Match? {
        return sportsDao.getMatchById(id)
    }

    suspend fun getChannelById(id: Int): Channel? {
        return sportsDao.getChannelById(id)
    }

    suspend fun insertMatch(match: Match) {
        sportsDao.insertMatch(match)
    }

    suspend fun deleteMatchById(id: Int) {
        sportsDao.deleteMatchById(id)
    }

    suspend fun insertChannel(channel: Channel) {
        sportsDao.insertChannel(channel)
    }

    suspend fun deleteChannelById(id: Int) {
        sportsDao.deleteChannelById(id)
    }

    suspend fun insertCategory(category: Category) {
        sportsDao.insertCategory(category)
    }

    suspend fun deleteCategoryById(id: Int) {
        sportsDao.deleteCategoryById(id)
    }
}
