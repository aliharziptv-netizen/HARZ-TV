package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "matches")
data class Match(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val homeTeam: String = "",
    val awayTeam: String = "",
    val homeTeamLogo: String = "",
    val awayTeamLogo: String = "",
    val matchTime: String = "", // e.g. "20:45"
    val matchDate: String = "", // e.g. "2026-07-16"
    val leagueName: String = "", // e.g. "الدوري الإسباني"
    val status: String = "NOT_STARTED", // "NOT_STARTED", "LIVE", "FINISHED"
    val channelName: String = "",
    val streamUrl: String = "", // M3U8, MP4 or embedded URL
    val homeScore: Int = 0,
    val awayScore: Int = 0,
    val commentator: String = ""
)

@Entity(tableName = "channels")
data class Channel(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String = "",
    val logoUrl: String = "",
    val streamUrl: String = "", // M3U8, MP4, or web stream URL
    val category: String = "", // e.g. "Sports", "News", "Movies"
    val isFavorite: Boolean = false
)

@Entity(tableName = "categories")
data class Category(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String = "", // e.g. "الدوري الإنجليزي", "قنوات رياضية"
    val type: String = "MATCH" // "MATCH" or "CHANNEL"
)
