package com.example.data

import kotlinx.serialization.KSerializer
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.descriptors.PrimitiveKind
import kotlinx.serialization.descriptors.PrimitiveSerialDescriptor
import kotlinx.serialization.descriptors.SerialDescriptor
import kotlinx.serialization.encoding.Decoder
import kotlinx.serialization.encoding.Encoder
import kotlinx.serialization.json.JsonDecoder
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.intOrNull

object FlexibleIntSerializer : KSerializer<Int> {
    override val descriptor: SerialDescriptor = PrimitiveSerialDescriptor("FlexibleInt", PrimitiveKind.INT)

    override fun deserialize(decoder: Decoder): Int {
        val jsonDecoder = decoder as? JsonDecoder ?: return try { decoder.decodeInt() } catch (e: Exception) { 0 }
        return try {
            val element = jsonDecoder.decodeJsonElement()
            when (element) {
                is JsonPrimitive -> {
                    if (element.isString) {
                        element.content.toIntOrNull() ?: element.content.hashCode()
                    } else {
                        element.intOrNull ?: element.content.toIntOrNull() ?: 0
                    }
                }
                else -> 0
            }
        } catch (e: Exception) {
            0
        }
    }

    override fun serialize(encoder: Encoder, value: Int) {
        encoder.encodeInt(value)
    }
}

@Serializable
data class Category(
    @Serializable(with = FlexibleIntSerializer::class)
    val id: Int = 0,
    @SerialName("name")
    val rawName: String? = null,
    @SerialName("category_name")
    val categoryName: String? = null,
    @SerialName("name_ar")
    val nameAr: String? = null,
    @SerialName("name_en")
    val nameEn: String? = null,
    val title: String? = null,
    val category: String? = null,
    val label: String? = null,
    @SerialName("logo_url")
    val logoUrl: String? = null,
    @SerialName("logo")
    val logoAlt: String? = null,
    @SerialName("image")
    val imageAlt: String? = null,
    @SerialName("icon")
    val iconAlt: String? = null,
    @SerialName("created_at")
    val createdAt: String? = null
) {
    val name: String
        get() = rawName ?: categoryName ?: nameAr ?: nameEn ?: title ?: category ?: label ?: "قسم $id"

    val displayLogo: String?
        get() = logoUrl ?: logoAlt ?: imageAlt ?: iconAlt
}

@Serializable
data class Channel(
    @Serializable(with = FlexibleIntSerializer::class)
    val id: Int = 0,
    @Serializable(with = FlexibleIntSerializer::class)
    @SerialName("category_id")
    val rawCategoryId: Int = 0,
    @Serializable(with = FlexibleIntSerializer::class)
    @SerialName("cat_id")
    val altCatId: Int = 0,
    @SerialName("category_name")
    val categoryName: String? = null,
    @SerialName("cat_name")
    val catNameAlt: String? = null,
    @SerialName("category")
    val categoryStr: String? = null,
    @SerialName("channel_name")
    val rawChannelName: String? = null,
    val name: String? = null,
    val title: String? = null,
    @SerialName("logo_url")
    val logoUrl: String? = null,
    @SerialName("logo")
    val logoAlt: String? = null,
    @SerialName("image")
    val imageAlt: String? = null,
    @SerialName("m3u_url")
    val rawStreamUrl: String? = null,
    @SerialName("stream_url")
    val streamUrlAlt: String? = null,
    @SerialName("m3u8_url")
    val m3u8Url: String? = null,
    @SerialName("m3u8")
    val m3u8: String? = null,
    @SerialName("m3u8_link")
    val m3u8Link: String? = null,
    @SerialName("stream")
    val stream: String? = null,
    @SerialName("stream_link")
    val streamLink: String? = null,
    @SerialName("channel_url")
    val channelUrl: String? = null,
    @SerialName("play_url")
    val playUrl: String? = null,
    @SerialName("video_url")
    val videoUrl: String? = null,
    @SerialName("hls_url")
    val hlsUrl: String? = null,
    @SerialName("src")
    val src: String? = null,
    @SerialName("source")
    val source: String? = null,
    @SerialName("file")
    val file: String? = null,
    @SerialName("uri")
    val uri: String? = null,
    @SerialName("iptv_url")
    val iptvUrl: String? = null,
    val m3u: String? = null,
    val url: String? = null,
    val link: String? = null,
    @SerialName("is_active")
    val isActive: Boolean? = true,
    @SerialName("created_at")
    val createdAt: String? = null
) {
    val categoryId: Int
        get() = if (rawCategoryId != 0) rawCategoryId else altCatId

    val channelName: String
        get() = rawChannelName ?: name ?: title ?: "قناة"

    val streamUrl: String
        get() {
            val candidate = rawStreamUrl
                ?: streamUrlAlt
                ?: m3u8Url
                ?: m3u8
                ?: m3u8Link
                ?: stream
                ?: streamLink
                ?: channelUrl
                ?: playUrl
                ?: videoUrl
                ?: hlsUrl
                ?: src
                ?: source
                ?: file
                ?: uri
                ?: iptvUrl
                ?: m3u
                ?: url
                ?: link
                ?: ""
            return candidate.trim()
        }

    val displayLogo: String?
        get() = logoUrl ?: logoAlt ?: imageAlt
}

@Serializable
data class AdSettings(
    @Serializable(with = FlexibleIntSerializer::class)
    val id: Int = 0,
    @SerialName("company_name")
    val companyName: String? = null,
    val platform: String? = null,
    @SerialName("app_id")
    val appId: String? = null,
    @SerialName("banner_unit_id")
    val bannerUnitId: String? = null,
    @SerialName("interstitial_unit_id")
    val interstitialUnitId: String? = null,
    @SerialName("is_enabled")
    val isEnabled: Boolean = true
) {
    val platformName: String
        get() = companyName ?: platform ?: "AdMob"
}


