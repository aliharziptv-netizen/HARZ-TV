package com.example.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import okhttp3.Request
import javax.inject.Inject

class MainRepository @Inject constructor(
    private val okHttpClient: OkHttpClient,
    private val json: Json,
    private val firebaseDbUrl: String,
    private val firebaseApiKey: String
) {

    private inline fun <reified T> parseFirebaseData(body: String): List<T> {
        val trimmed = body.trim()
        if (trimmed.isEmpty() || trimmed == "null") return emptyList()

        if (trimmed.startsWith("[")) {
            return try {
                json.decodeFromString<List<T?>>(trimmed).filterNotNull()
            } catch (e: Exception) {
                e.printStackTrace()
                emptyList()
            }
        } else if (trimmed.startsWith("{")) {
            return try {
                val map = json.decodeFromString<Map<String, T>>(trimmed)
                map.values.toList()
            } catch (e: Exception) {
                e.printStackTrace()
                emptyList()
            }
        }
        return emptyList()
    }

    private fun fetchFromFirebase(endpointPath: String): String? {
        val baseUrl = firebaseDbUrl.removeSuffix("/")
        val cleanPath = endpointPath.removePrefix("/")
        
        // Try with auth query parameter first
        val urlsToTry = listOf(
            "$baseUrl/$cleanPath.json?auth=$firebaseApiKey",
            "$baseUrl/$cleanPath.json"
        )

        for (url in urlsToTry) {
            try {
                val request = Request.Builder()
                    .url(url)
                    .get()
                    .build()

                okHttpClient.newCall(request).execute().use { res ->
                    val body = res.body?.string()
                    if (res.isSuccessful && !body.isNullOrBlank() && body.trim() != "null") {
                        return body
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        return null
    }

    suspend fun getCategories(): List<Category> = withContext(Dispatchers.IO) {
        val categoryPaths = listOf("categories", "Categories", "category", "")
        for (path in categoryPaths) {
            val body = fetchFromFirebase(path)
            if (!body.isNullOrBlank()) {
                var list: List<Category> = parseFirebaseData(body)
                if (list.isNotEmpty()) {
                    // Ensure every category has a unique non-zero ID
                    val usedIds = mutableSetOf<Int>()
                    list = list.mapIndexed { index, cat ->
                        var catId = cat.id
                        if (catId <= 0 || usedIds.contains(catId)) {
                            catId = index + 1
                            while (usedIds.contains(catId)) {
                                catId++
                            }
                        }
                        usedIds.add(catId)
                        cat.copy(id = catId)
                    }
                    return@withContext list
                }
            }
        }
        return@withContext emptyList()
    }

    suspend fun getChannels(): List<Channel> = withContext(Dispatchers.IO) {
        val channelPaths = listOf("channels", "Channels", "channel", "")
        for (path in channelPaths) {
            val body = fetchFromFirebase(path)
            if (!body.isNullOrBlank()) {
                var list: List<Channel> = parseFirebaseData(body)
                if (list.isNotEmpty()) {
                    val activeList = list.filter { it.isActive != false }
                    val usedIds = mutableSetOf<Int>()
                    val fixedList = activeList.mapIndexed { index, ch ->
                        var chId = ch.id
                        if (chId <= 0 || usedIds.contains(chId)) {
                            chId = index + 1
                            while (usedIds.contains(chId)) {
                                chId++
                            }
                        }
                        usedIds.add(chId)
                        ch.copy(id = chId)
                    }
                    return@withContext fixedList
                }
            }
        }
        return@withContext emptyList()
    }

    suspend fun getAdSettings(): List<AdSettings> = withContext(Dispatchers.IO) {
        val adsPaths = listOf("ads_settings", "ad_settings", "ads", "Ads")
        for (path in adsPaths) {
            val body = fetchFromFirebase(path)
            if (!body.isNullOrBlank()) {
                val list: List<AdSettings> = parseFirebaseData(body)
                if (list.isNotEmpty()) {
                    return@withContext list
                }
            }
        }

        return@withContext listOf(
            AdSettings(id = 1, companyName = "AdMob", isEnabled = true),
            AdSettings(id = 2, companyName = "StartApp", isEnabled = true),
            AdSettings(id = 3, companyName = "UnityAds", isEnabled = true)
        )
    }
}

