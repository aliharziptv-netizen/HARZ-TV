package com.example.data

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

object AdManager {

    private const val TAG = "HARZ_TV_AdManager"
    // AdMob Sample Interstitial Unit ID
    private const val ADMOB_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712"

    private var interstitialAd: InterstitialAd? = null
    private var isLoadingAd = false

    fun loadInterstitialAd(context: Context) {
        if (interstitialAd != null || isLoadingAd) return
        isLoadingAd = true

        try {
            val adRequest = AdRequest.Builder().build()
            InterstitialAd.load(
                context.applicationContext,
                ADMOB_INTERSTITIAL_ID,
                adRequest,
                object : InterstitialAdLoadCallback() {
                    override fun onAdLoaded(ad: InterstitialAd) {
                        interstitialAd = ad
                        isLoadingAd = false
                        Log.d(TAG, "AdMob Interstitial loaded successfully.")
                    }

                    override fun onAdFailedToLoad(adError: LoadAdError) {
                        interstitialAd = null
                        isLoadingAd = false
                        Log.e(TAG, "AdMob Interstitial failed to load: ${adError.message}")
                    }
                }
            )
        } catch (e: Throwable) {
            isLoadingAd = false
            interstitialAd = null
            Log.e(TAG, "AdMob Interstitial load exception: ${e.message}")
        }
    }

    fun showInterstitialAd(activity: Activity, onAdDismissedOrFailed: () -> Unit) {
        val ad = interstitialAd
        if (ad != null) {
            try {
                ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() {
                        interstitialAd = null
                        loadInterstitialAd(activity)
                        onAdDismissedOrFailed()
                    }

                    override fun onAdFailedToShowFullScreenContent(adError: com.google.android.gms.ads.AdError) {
                        interstitialAd = null
                        loadInterstitialAd(activity)
                        onAdDismissedOrFailed()
                    }
                }
                ad.show(activity)
            } catch (e: Throwable) {
                interstitialAd = null
                Log.e(TAG, "AdMob Interstitial show exception: ${e.message}")
                onAdDismissedOrFailed()
            }
        } else {
            onAdDismissedOrFailed()
            loadInterstitialAd(activity)
        }
    }
}

