package com.example.ui.screens

import android.annotation.SuppressLint
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.SubcomposeAsyncImage
import coil.request.ImageRequest
import com.example.data.Category
import com.example.data.Channel
import com.example.ui.UiState
import com.example.ui.theme.*
import com.example.ui.theme.BrightCyan
import com.example.ui.theme.CardDark
import com.example.ui.theme.DarkCyan
import com.example.ui.theme.DeepBlack
import com.example.ui.theme.MidCyan
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SubtextGray
import com.example.ui.theme.SurfaceDark
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    uiState: UiState,
    onCategorySelected: (Int?) -> Unit,
    onSearchQueryChanged: (String) -> Unit,
    onChannelClick: (Channel) -> Unit,
    onRefresh: () -> Unit,
    onAddCustomChannel: (String, String, String?) -> Unit = { _, _, _ -> }
) {
    // FORCE RIGHT-TO-LEFT LAYOUT FOR ARABIC READABILITY
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        val context = LocalContext.current
        val prefs = remember { context.getSharedPreferences("app_prefs", android.content.Context.MODE_PRIVATE) }
        val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
        val scope = rememberCoroutineScope()
        var isCategoriesViewMode by remember {
            mutableStateOf(prefs.getBoolean("is_categories_view_mode", false))
        }

        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                ModalDrawerSheet(
                    drawerContainerColor = SurfaceDark,
                    drawerContentColor = PureWhite,
                    modifier = Modifier.width(300.dp)
                ) {
                    // Drawer Header
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(DarkCyan, CardDark)
                                )
                            )
                            .padding(24.dp)
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(CircleShape)
                                        .background(DeepBlack)
                                        .border(1.dp, BrightCyan, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.LiveTv,
                                        contentDescription = "Logo",
                                        tint = BrightCyan,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "HARZ TV",
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = BrightCyan
                                    )
                                    Text(
                                        text = "تطبيق البث المباشر",
                                        fontSize = 12.sp,
                                        color = SubtextGray
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "القوائم والأقسام",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MidCyan,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                    )

                    // Navigation Drawer Item: All channels
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.Tv, contentDescription = null, tint = BrightCyan) },
                        label = { Text("كل القنوات المتاحة", color = PureWhite, fontWeight = FontWeight.Bold) },
                        selected = uiState.selectedCategoryId == null,
                        onClick = {
                            onCategorySelected(null)
                            scope.launch { drawerState.close() }
                        },
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = DarkCyan.copy(alpha = 0.3f)
                        ),
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )

                    HorizontalDivider(
                        modifier = Modifier.padding(vertical = 12.dp, horizontal = 16.dp),
                        color = CardDark
                    )

                    Text(
                        text = "الأقسام المتاحة",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MidCyan,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
                    )

                    // List of Categories in Drawer
                    uiState.categories.forEach { category ->
                        NavigationDrawerItem(
                            icon = { Icon(Icons.Default.Category, contentDescription = null, tint = MidCyan) },
                            label = { Text(category.name, color = PureWhite) },
                            selected = uiState.selectedCategoryId == category.id,
                            onClick = {
                                onCategorySelected(category.id)
                                scope.launch { drawerState.close() }
                            },
                            colors = NavigationDrawerItemDefaults.colors(
                                selectedContainerColor = DarkCyan.copy(alpha = 0.3f)
                            ),
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
                        )
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    // Drawer Footer
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CardDark)
                            .padding(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Info, contentDescription = null, tint = SubtextGray, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "إصدار التطبيق v1.0.0 - HARZ TV",
                                fontSize = 12.sp,
                                color = SubtextGray
                            )
                        }
                    }
                }
            }
        ) {
            Scaffold(
                containerColor = DeepBlack,
                topBar = {
                    TopAppBar(
                        title = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "HARZ TV",
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.Black,
                                    color = BrightCyan
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(DarkCyan)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "مباشر",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = PureWhite
                                    )
                                }
                            }
                        },
                        navigationIcon = {
                            IconButton(
                                onClick = { scope.launch { drawerState.open() } },
                                modifier = Modifier.testTag("menu_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Menu,
                                    contentDescription = "القائمة",
                                    tint = BrightCyan
                                )
                            }
                        },
                        actions = {
                            IconButton(
                                onClick = {
                                    val newMode = !isCategoriesViewMode
                                    isCategoriesViewMode = newMode
                                    prefs.edit().putBoolean("is_categories_view_mode", newMode).apply()
                                },
                                modifier = Modifier.testTag("toggle_categories_mode_button")
                            ) {
                                Icon(
                                    imageVector = if (isCategoriesViewMode) Icons.Default.Tv else Icons.Default.Category,
                                    contentDescription = if (isCategoriesViewMode) "عرض القنوات" else "عرض التصنيفات كقنوات",
                                    tint = if (isCategoriesViewMode) AccentGreen else MidCyan
                                )
                            }
                            IconButton(onClick = onRefresh, modifier = Modifier.testTag("refresh_button")) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "تحديث البيانات",
                                    tint = MidCyan
                                )
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = SurfaceDark,
                            titleContentColor = BrightCyan
                        )
                    )
                },
                bottomBar = {
                    // Anchored Banner Ad View
                    BannerAdView()
                }
            ) { innerPadding ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .background(DeepBlack)
                ) {
                    // Search Bar
                    SearchBarSection(
                        query = uiState.searchQuery,
                        onQueryChanged = onSearchQueryChanged
                    )

                    // Categories Horizontal Scroll Row
                    if (!isCategoriesViewMode) {
                        CategoriesRow(
                            categories = uiState.categories,
                            selectedCategoryId = uiState.selectedCategoryId,
                            onCategorySelected = onCategorySelected
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    // Content Area: Loading, Error, or Channels Grid
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f)
                    ) {
                        when {
                            uiState.isLoading -> {
                                Column(
                                    modifier = Modifier.fillMaxSize(),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    CircularProgressIndicator(color = BrightCyan)
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Text(
                                        text = "جاري تحميل قائمة القنوات...",
                                        color = MidCyan,
                                        fontSize = 14.sp
                                    )
                                }
                            }

                            uiState.errorMessage != null && uiState.filteredChannels.isEmpty() -> {
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Tv,
                                        contentDescription = null,
                                        tint = SubtextGray,
                                        modifier = Modifier.size(64.dp)
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Text(
                                        text = uiState.errorMessage,
                                        color = PureWhite,
                                        textAlign = TextAlign.Center,
                                        fontSize = 15.sp
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(DarkCyan)
                                            .clickable { onRefresh() }
                                            .padding(horizontal = 20.dp, vertical = 10.dp)
                                    ) {
                                        Text("إعادة المحاولة", color = PureWhite, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            isCategoriesViewMode -> {
                                CategoriesGrid(
                                    categories = uiState.categories,
                                    channels = uiState.channels,
                                    selectedCategoryId = uiState.selectedCategoryId,
                                    onCategoryClick = { catId ->
                                        onCategorySelected(catId)
                                        isCategoriesViewMode = false
                                        prefs.edit().putBoolean("is_categories_view_mode", false).apply()
                                    }
                                )
                            }

                            uiState.filteredChannels.isEmpty() -> {
                                Column(
                                    modifier = Modifier.fillMaxSize(),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Tv,
                                        contentDescription = null,
                                        tint = SubtextGray,
                                        modifier = Modifier.size(56.dp)
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        text = "لا توجد قنوات متاحة في هذا القسم",
                                        color = SubtextGray,
                                        fontSize = 14.sp
                                    )
                                }
                            }

                            else -> {
                                ChannelsGrid(
                                    channels = uiState.filteredChannels,
                                    onChannelClick = onChannelClick
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SearchBarSection(
    query: String,
    onQueryChanged: (String) -> Unit
) {
    val focusManager = LocalFocusManager.current

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        OutlinedTextField(
            value = query,
            onValueChange = onQueryChanged,
            placeholder = { Text("ابحث عن قناتك المفضلة...", color = SubtextGray, fontSize = 13.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "بحث", tint = MidCyan) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { onQueryChanged("") }) {
                        Icon(Icons.Default.Clear, contentDescription = "مسح", tint = SubtextGray)
                    }
                }
            },
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() }),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = BrightCyan,
                unfocusedBorderColor = DarkCyan.copy(alpha = 0.5f),
                focusedContainerColor = CardDark,
                unfocusedContainerColor = CardDark,
                focusedTextColor = PureWhite,
                unfocusedTextColor = PureWhite
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("search_input")
        )
    }
}

@Composable
fun CategoriesRow(
    categories: List<Category>,
    selectedCategoryId: Int?,
    onCategorySelected: (Int?) -> Unit
) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        // "All Channels" Pill at the start
        item {
            val isSelected = selectedCategoryId == null
            CategoryPill(
                title = "كل القنوات",
                isSelected = isSelected,
                onClick = { onCategorySelected(null) }
            )
        }

        itemsIndexed(categories, key = { index, category -> "cat_row_${category.id}_$index" }) { _, category ->
            val isSelected = selectedCategoryId == category.id
            CategoryPill(
                title = category.name,
                isSelected = isSelected,
                onClick = { onCategorySelected(category.id) }
            )
        }
    }
}

@Composable
fun CategoryPill(
    title: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .shadow(if (isSelected) 8.dp else 0.dp, shape = RoundedCornerShape(20.dp), spotColor = AccentGreen)
            .clip(RoundedCornerShape(20.dp))
            .background(
                if (isSelected) {
                    Brush.horizontalGradient(listOf(DarkGreen, MidGreen))
                } else {
                    Brush.horizontalGradient(listOf(CardDark, CardDark))
                }
            )
            .border(
                width = 1.dp,
                color = if (isSelected) AccentGreen else Color(0xFF22222E),
                shape = RoundedCornerShape(20.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = title,
            fontSize = 13.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) PureWhite else SubtextGray
        )
    }
}

@Composable
fun ChannelsGrid(
    channels: List<Channel>,
    onChannelClick: (Channel) -> Unit
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier
            .fillMaxSize()
            .testTag("channels_grid")
    ) {
        itemsIndexed(channels, key = { index, channel -> "ch_${channel.id}_$index" }) { _, channel ->
            ChannelCard(
                channel = channel,
                onClick = { onChannelClick(channel) }
            )
        }
    }
}

@SuppressLint("ModifierParameter")
@Composable
fun ChannelCard(
    channel: Channel,
    onClick: () -> Unit
) {
    var isPressed by remember { mutableStateOf(false) }
    val scaleFactor by animateFloatAsState(
        targetValue = if (isPressed) 0.92f else 1.0f,
        label = "scale"
    )

    Box(
        modifier = Modifier
            .scale(scaleFactor)
            .shadow(6.dp, shape = RoundedCornerShape(12.dp), ambientColor = BrightCyan, spotColor = BrightCyan)
            .clip(RoundedCornerShape(12.dp))
            .background(CardDark)
            .border(1.dp, DarkCyan.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        isPressed = true
                        tryAwaitRelease()
                        isPressed = false
                    },
                    onTap = { onClick() }
                )
            }
            .aspectRatio(0.82f)
            .testTag("channel_card_${channel.id}")
    ) {
        // Channel Logo / Image with Coil
        if (!channel.displayLogo.isNullOrBlank()) {
            SubcomposeAsyncImage(
                model = ImageRequest.Builder(LocalContext.current)
                    .data(channel.displayLogo)
                    .crossfade(true)
                    .build(),
                contentDescription = channel.channelName,
                contentScale = ContentScale.Crop,
                loading = {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MidCyan, strokeWidth = 2.dp)
                    }
                },
                error = {
                    ChannelLogoFallback(channelName = channel.channelName)
                },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            ChannelLogoFallback(channelName = channel.channelName)
        }

        // Gradient Overlay at bottom for readable text
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Transparent,
                            DeepBlack.copy(alpha = 0.4f),
                            DeepBlack.copy(alpha = 0.95f)
                        )
                    )
                )
        )

        // Live Badge Indicator at top
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(6.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(Color.Red.copy(alpha = 0.85f))
                .padding(horizontal = 5.dp, vertical = 2.dp)
        ) {
            Text(
                text = "مباشر",
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = PureWhite
            )
        }

        // Channel Name & Play Icon at bottom
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = channel.channelName,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = PureWhite,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )

                Spacer(modifier = Modifier.width(4.dp))

                Box(
                    modifier = Modifier
                        .size(20.dp)
                        .clip(CircleShape)
                        .background(BrightCyan),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "تشغيل",
                        tint = DeepBlack,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ChannelLogoFallback(channelName: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(DarkCyan.copy(alpha = 0.4f), CardDark)
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = Icons.Default.Tv,
                contentDescription = null,
                tint = BrightCyan.copy(alpha = 0.8f),
                modifier = Modifier.size(32.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = channelName.take(12),
                fontSize = 10.sp,
                color = MidCyan,
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun BannerAdView() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(SurfaceDark)
            .padding(vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        AndroidView(
            factory = { context ->
                try {
                    AdView(context).apply {
                        setAdSize(AdSize.BANNER)
                        adUnitId = "ca-app-pub-3940256099942544/6300978111"
                        try {
                            loadAd(AdRequest.Builder().build())
                        } catch (e: Throwable) {
                            e.printStackTrace()
                        }
                    }
                } catch (e: Throwable) {
                    e.printStackTrace()
                    android.view.View(context)
                }
            },
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun CategoriesGrid(
    categories: List<Category>,
    channels: List<Channel>,
    selectedCategoryId: Int?,
    onCategoryClick: (Int?) -> Unit
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier
            .fillMaxSize()
            .testTag("categories_grid")
    ) {
        // "All Channels" Card
        item(key = "all_channels_category_card") {
            CategoryCard(
                categoryName = "كل القنوات",
                logoUrl = channels.firstOrNull { !it.displayLogo.isNullOrBlank() }?.displayLogo,
                channelCount = channels.size,
                isSelected = selectedCategoryId == null,
                onClick = { onCategoryClick(null) }
            )
        }

        itemsIndexed(categories, key = { index, category -> "cat_card_${category.id}_$index" }) { _, category ->
            val catChannels = channels.filter { channel ->
                channel.categoryId == category.id ||
                        (channel.altCatId != 0 && channel.altCatId == category.id) ||
                        (!channel.categoryName.isNullOrBlank() && channel.categoryName.equals(category.name, ignoreCase = true)) ||
                        (!channel.catNameAlt.isNullOrBlank() && channel.catNameAlt.equals(category.name, ignoreCase = true)) ||
                        (!channel.categoryStr.isNullOrBlank() && channel.categoryStr.equals(category.name, ignoreCase = true))
            }
            val sampleLogo = category.displayLogo ?: catChannels.firstOrNull { !it.displayLogo.isNullOrBlank() }?.displayLogo

            CategoryCard(
                categoryName = category.name,
                logoUrl = sampleLogo,
                channelCount = catChannels.size,
                isSelected = selectedCategoryId == category.id,
                onClick = { onCategoryClick(category.id) }
            )
        }
    }
}

@SuppressLint("ModifierParameter")
@Composable
fun CategoryCard(
    categoryName: String,
    logoUrl: String?,
    channelCount: Int,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    var isPressed by remember { mutableStateOf(false) }
    val scaleFactor by animateFloatAsState(
        targetValue = if (isPressed) 0.92f else 1.0f,
        label = "scale"
    )

    Box(
        modifier = Modifier
            .scale(scaleFactor)
            .shadow(
                elevation = if (isSelected) 8.dp else 6.dp,
                shape = RoundedCornerShape(12.dp),
                spotColor = if (isSelected) AccentGreen else BrightCyan
            )
            .clip(RoundedCornerShape(12.dp))
            .background(CardDark)
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) AccentGreen else DarkCyan.copy(alpha = 0.6f),
                shape = RoundedCornerShape(12.dp)
            )
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        isPressed = true
                        tryAwaitRelease()
                        isPressed = false
                    },
                    onTap = { onClick() }
                )
            }
            .aspectRatio(0.82f)
            .testTag("category_card_$categoryName")
    ) {
        if (!logoUrl.isNullOrBlank()) {
            SubcomposeAsyncImage(
                model = ImageRequest.Builder(LocalContext.current)
                    .data(logoUrl)
                    .crossfade(true)
                    .build(),
                contentDescription = categoryName,
                contentScale = ContentScale.Crop,
                loading = {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MidCyan, strokeWidth = 2.dp)
                    }
                },
                error = {
                    CategoryLogoFallback(categoryName = categoryName)
                },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            CategoryLogoFallback(categoryName = categoryName)
        }

        // Gradient Overlay
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Transparent,
                            DeepBlack.copy(alpha = 0.4f),
                            DeepBlack.copy(alpha = 0.95f)
                        )
                    )
                )
        )

        // Badge at top
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(6.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(if (isSelected) AccentGreen else MidCyan)
                .padding(horizontal = 5.dp, vertical = 2.dp)
        ) {
            Text(
                text = if (channelCount > 0) "$channelCount قناة" else "قسم",
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = DeepBlack
            )
        }

        // Category Name & Icon at bottom
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = categoryName,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = PureWhite,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )

                Spacer(modifier = Modifier.width(4.dp))

                Box(
                    modifier = Modifier
                        .size(20.dp)
                        .clip(CircleShape)
                        .background(if (isSelected) AccentGreen else BrightCyan),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Category,
                        contentDescription = "عرض القسم",
                        tint = DeepBlack,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun CategoryLogoFallback(categoryName: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(DarkGreen.copy(alpha = 0.5f), CardDark)
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = Icons.Default.Category,
                contentDescription = null,
                tint = AccentGreen.copy(alpha = 0.9f),
                modifier = Modifier.size(32.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = categoryName.take(12),
                fontSize = 10.sp,
                color = PureWhite,
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
