package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BrightCyan
import com.example.ui.theme.DarkCyan
import com.example.ui.theme.DeepBlack
import com.example.ui.theme.MidCyan
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SubtextGray
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
    onNavigateToHome: () -> Unit
) {
    val scale = remember { Animatable(0.6f) }
    val alpha = remember { Animatable(0f) }

    LaunchedEffect(key1 = true) {
        scale.animateTo(
            targetValue = 1.0f,
            animationSpec = tween(durationMillis = 1000, easing = FastOutSlowInEasing)
        )
        alpha.animateTo(
            targetValue = 1.0f,
            animationSpec = tween(durationMillis = 800)
        )
        delay(2200)
        onNavigateToHome()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
            .testTag("splash_screen"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(24.dp)
        ) {
            // Glowing Neon TV Logo Icon Box
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .scale(scale.value)
                    .size(130.dp)
                    .shadow(24.dp, shape = CircleShape, ambientColor = BrightCyan, spotColor = BrightCyan)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(DarkCyan, DeepBlack)
                        )
                    )
                    .border(2.dp, BrightCyan, CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.Tv,
                    contentDescription = "HARZ TV Logo",
                    tint = BrightCyan,
                    modifier = Modifier.size(70.dp)
                )
            }

            Spacer(modifier = Modifier.height(32.dp))

            // App Title
            Text(
                text = "HARZ TV",
                fontSize = 38.sp,
                fontWeight = FontWeight.Black,
                color = BrightCyan,
                letterSpacing = 2.sp,
                modifier = Modifier.alpha(alpha.value)
            )

            Text(
                text = "بث مباشر للقنوات الفضائية والترفيه",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MidCyan,
                modifier = Modifier
                    .padding(top = 4.dp)
                    .alpha(alpha.value)
            )

            Spacer(modifier = Modifier.height(36.dp))

            // Arabic Welcome Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .alpha(alpha.value)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF101014))
                    .border(1.dp, Brush.horizontalGradient(listOf(DarkCyan, MidCyan, DarkCyan)), RoundedCornerShape(16.dp))
                    .padding(20.dp)
            ) {
                Text(
                    text = "مرحباً بكم في تطبيق HARZ TV، وجهتكم الأولى لأفضل القنوات الفضائية والترفيه المتميز بدون تقطيع!",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                    color = PureWhite,
                    textAlign = TextAlign.Center,
                    lineHeight = 24.sp
                )
            }

            Spacer(modifier = Modifier.height(48.dp))

            // Loading status subtext
            Text(
                text = "جاري الاتصال بالسيرفر والتحديث...",
                fontSize = 13.sp,
                color = SubtextGray,
                modifier = Modifier.alpha(alpha.value)
            )
        }
    }
}
