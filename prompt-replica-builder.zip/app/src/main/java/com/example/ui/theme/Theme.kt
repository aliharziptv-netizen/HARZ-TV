package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val CyberNeonColorScheme = darkColorScheme(
    primary = BrightCyan,
    onPrimary = DeepBlack,
    primaryContainer = DarkCyan,
    onPrimaryContainer = PureWhite,
    secondary = MidCyan,
    onSecondary = DeepBlack,
    tertiary = BrightCyan,
    background = DeepBlack,
    onBackground = PureWhite,
    surface = SurfaceDark,
    onSurface = PureWhite,
    surfaceVariant = CardDark,
    onSurfaceVariant = SubtextGray
)

@Composable
fun HARZTVTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = CyberNeonColorScheme,
        typography = Typography,
        content = content
    )
}

