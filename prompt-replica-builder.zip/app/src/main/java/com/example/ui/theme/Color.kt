package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DeepBlack = Color(0xFF000000)
val SurfaceDark = Color(0xFF0A0A0A)
val CardDark = Color(0xFF101014)

val BrightCyan = Color(0xFF00FFFF)
val MidCyan = Color(0xFF00CCCC)
val DarkCyan = Color(0xFF008080)

val AccentGreen = Color(0xFF00E676)
val DarkGreen = Color(0xFF064E3B)
val MidGreen = Color(0xFF059669)

val PureWhite = Color(0xFFF0F0F0)
val SubtextGray = Color(0xFF999999)

