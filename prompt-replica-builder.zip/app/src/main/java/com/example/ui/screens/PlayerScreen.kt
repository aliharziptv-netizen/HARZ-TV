package com.example.ui.screens

import android.app.Activity
import android.content.pm.ActivityInfo
import android.net.Uri
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.example.data.AdManager
import com.example.ui.theme.BrightCyan
import com.example.ui.theme.DarkCyan
import com.example.ui.theme.DeepBlack
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SubtextGray
import kotlinx.coroutines.delay

enum class FitMode(val label: String, val resizeMode: Int) {
    FIT("Fit", AspectRatioFrameLayout.RESIZE_MODE_FIT),
    FILL("Fill", AspectRatioFrameLayout.RESIZE_MODE_FILL),
    ZOOM("Zoom", AspectRatioFrameLayout.RESIZE_MODE_ZOOM),
    RATIO_16_9("16:9", AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH)
}

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    streamUrl: String,
    channelName: String,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity

    if (streamUrl.isBlank()) {
        LaunchedEffect(Unit) {
            Toast.makeText(context, "عذراً، رابط القناة غير متوفر", Toast.LENGTH_SHORT).show()
            onBack()
        }
        return
    }

    // Secure URL formatting
    val formattedUrl = remember(streamUrl) {
        val trimmed = streamUrl.trim()
        if (!trimmed.startsWith("http://") && !trimmed.startsWith("https://")) {
            "http://$trimmed"
        } else {
            trimmed
        }
    }

    var isAdShown by remember { mutableStateOf(false) }
    var isPlayerInitialized by remember { mutableStateOf(false) }
    var exoPlayer by remember { mutableStateOf<ExoPlayer?>(null) }
    var isBuffering by remember { mutableStateOf(true) }
    var isPlaying by remember { mutableStateOf(false) }
    var hasError by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }
    var showControls by remember { mutableStateOf(true) }
    var isLocked by remember { mutableStateOf(false) }
    var fitMode by remember { mutableStateOf(FitMode.FIT) }
    var isMuted by remember { mutableStateOf(false) }

    var currentPositionMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var isLiveStream by remember { mutableStateOf(true) }

    var showQualityDialog by remember { mutableStateOf(false) }
    var showAudioDialog by remember { mutableStateOf(false) }
    var selectedQuality by remember { mutableStateOf("تلقائي (Auto)") }

    // Immersive Landscape Fullscreen Mode Setup
    DisposableEffect(Unit) {
        val window = activity?.window
        val originalOrientation = try {
            activity?.requestedOrientation ?: ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        } catch (e: Exception) {
            ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }

        // Force landscape orientation for video playback safely
        try {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        } catch (e: Exception) {
            e.printStackTrace()
        }

        if (window != null) {
            try {
                WindowCompat.setDecorFitsSystemWindows(window, false)
                val controller = WindowCompat.getInsetsController(window, window.decorView)
                controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                controller.hide(WindowInsetsCompat.Type.systemBars())
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        onDispose {
            try {
                activity?.requestedOrientation = originalOrientation
            } catch (e: Exception) {
                e.printStackTrace()
            }
            if (window != null) {
                try {
                    WindowCompat.setDecorFitsSystemWindows(window, true)
                    val controller = WindowCompat.getInsetsController(window, window.decorView)
                    controller.show(WindowInsetsCompat.Type.systemBars())
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    // Interstitial Ad Flow
    LaunchedEffect(Unit) {
        if (!isAdShown && activity != null && !activity.isFinishing && !activity.isDestroyed) {
            try {
                AdManager.showInterstitialAd(activity) {
                    isAdShown = true
                    isPlayerInitialized = true
                }
            } catch (e: Exception) {
                e.printStackTrace()
                isAdShown = true
                isPlayerInitialized = true
            }
        } else {
            isPlayerInitialized = true
        }
    }

    // Auto Hide Overlay Controls (4s delay)
    LaunchedEffect(showControls, isLocked) {
        if (showControls && !isLocked) {
            delay(4000)
            showControls = false
        }
    }

    // Update Playback Position / Duration Loop
    LaunchedEffect(exoPlayer, isPlaying) {
        while (isPlaying && exoPlayer != null) {
            exoPlayer?.let { player ->
                currentPositionMs = player.currentPosition.coerceAtLeast(0L)
                durationMs = player.duration.coerceAtLeast(0L)
                isLiveStream = player.isCurrentMediaItemLive || durationMs <= 0 || durationMs == C.TIME_UNSET
            }
            delay(1000)
        }
    }

    // ExoPlayer Setup & M3U8 HLS Support
    if (isPlayerInitialized) {
        DisposableEffect(formattedUrl) {
            val userAgent = "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
            val httpDataSourceFactory = DefaultHttpDataSource.Factory()
                .setUserAgent(userAgent)
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(15000)

            val uri = Uri.parse(formattedUrl)

            var player: ExoPlayer? = null
            try {
                val mediaSourceFactory = androidx.media3.exoplayer.source.DefaultMediaSourceFactory(httpDataSourceFactory)
                val mediaItem = MediaItem.Builder()
                    .setUri(uri)
                    .build()
                val mediaSource = mediaSourceFactory.createMediaSource(mediaItem)

                player = ExoPlayer.Builder(context.applicationContext)
                    .setMediaSourceFactory(mediaSourceFactory)
                    .build().apply {
                    setMediaSource(mediaSource)
                    prepare()
                    playWhenReady = true
                    volume = if (isMuted) 0f else 1f
                    addListener(object : Player.Listener {
                        override fun onPlaybackStateChanged(playbackState: Int) {
                            isBuffering = playbackState == Player.STATE_BUFFERING
                            if (playbackState == Player.STATE_READY) {
                                hasError = false
                                isBuffering = false
                            }
                        }

                        override fun onIsPlayingChanged(playing: Boolean) {
                            isPlaying = playing
                        }

                        override fun onPlayerError(error: PlaybackException) {
                            isBuffering = false
                            hasError = true
                            errorMessage = "فشل تشغيل البث المباشر (m3u8): ${error.localizedMessage ?: "تأكد من الاتصال بالإنترنت"}"
                        }
                    })
                }
            } catch (e: Throwable) {
                e.printStackTrace()
                isBuffering = false
                hasError = true
                errorMessage = "خطأ في تشغيل مشغل الفيديو: ${e.localizedMessage ?: "خطأ غير معروف"}"
            }

            exoPlayer = player

            onDispose {
                try {
                    player?.release()
                } catch (e: Throwable) {
                    e.printStackTrace()
                }
                exoPlayer = null
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                showControls = !showControls
            }
            .testTag("player_screen")
    ) {
        // Player Video View Surface
        if (isPlayerInitialized && exoPlayer != null) {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        this.player = exoPlayer
                        useController = false
                        resizeMode = fitMode.resizeMode
                    }
                },
                update = { view ->
                    view.player = exoPlayer
                    view.resizeMode = fitMode.resizeMode
                },
                modifier = Modifier.fillMaxSize()
            )
        }

        // Center Loading Circular Progress Indicator
        if (isBuffering && !hasError) {
            Column(
                modifier = Modifier.align(Alignment.Center),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                CircularProgressIndicator(
                    color = PureWhite,
                    strokeWidth = 3.dp,
                    modifier = Modifier.size(56.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "جاري تحميل البث المباشر...",
                    color = PureWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Error State UI
        if (hasError) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(DeepBlack.copy(alpha = 0.92f)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "خطأ البث",
                        tint = Color.Red,
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "عذراً، تعذر الاتصال بخادم القناة",
                        color = PureWhite,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = errorMessage,
                        color = SubtextGray,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Row {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(BrightCyan)
                                .clickable {
                                    hasError = false
                                    isBuffering = true
                                    exoPlayer?.prepare()
                                    exoPlayer?.play()
                                }
                                .padding(horizontal = 16.dp, vertical = 10.dp)
                        ) {
                            Text("إعادة المحاولة", color = DeepBlack, fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(DarkCyan)
                                .clickable {
                                    try {
                                        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, Uri.parse(formattedUrl))
                                        context.startActivity(intent)
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "تعذر فتح الرابط", Toast.LENGTH_SHORT).show()
                                    }
                                }
                                .padding(horizontal = 16.dp, vertical = 10.dp)
                        ) {
                            Text("فتح الرابط خارجياً", color = PureWhite, fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.DarkGray)
                                .clickable { onBack() }
                                .padding(horizontal = 16.dp, vertical = 10.dp)
                        ) {
                            Text("خروج", color = PureWhite, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Screen Lock Overlay (When locked, only show padlock icon)
        if (isLocked) {
            AnimatedVisibility(
                visible = showControls,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(20.dp)
            ) {
                IconButton(
                    onClick = { isLocked = false },
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.6f))
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "إلغاء قفل الشاشة",
                        tint = PureWhite
                    )
                }
            }
        } else {
            // Full Overlay Controls (Top bar, Center Play/Pause, Bottom Control bar)
            AnimatedVisibility(
                visible = showControls,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.fillMaxSize()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.45f))
                ) {
                    // Top Header Bar Overlay
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.TopStart)
                            .background(Color.Black.copy(alpha = 0.6f))
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier.testTag("player_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "إغلاق",
                                tint = PureWhite,
                                modifier = Modifier.size(26.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Text(
                            text = channelName,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = PureWhite,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )

                        // Open Link in External Browser
                        IconButton(
                            onClick = {
                                try {
                                    val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, Uri.parse(formattedUrl))
                                    context.startActivity(intent)
                                } catch (e: Exception) {
                                    Toast.makeText(context, "تعذر فتح الرابط في المتصفح", Toast.LENGTH_SHORT).show()
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Public,
                                contentDescription = "فتح الرابط في المتصفح",
                                tint = BrightCyan
                            )
                        }

                        Spacer(modifier = Modifier.width(4.dp))

                        // Refresh Channel Stream
                        IconButton(
                            onClick = {
                                exoPlayer?.prepare()
                                exoPlayer?.play()
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "تحديث",
                                tint = PureWhite
                            )
                        }

                        Spacer(modifier = Modifier.width(4.dp))

                        // Lock Controls Button
                        IconButton(
                            onClick = { isLocked = true }
                        ) {
                            Icon(
                                imageVector = Icons.Default.LockOpen,
                                contentDescription = "قفل الشاشة",
                                tint = PureWhite
                            )
                        }
                    }

                    // Center Play/Pause Control
                    if (!isBuffering && !hasError) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.Center)
                                .size(68.dp)
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.5f))
                                .clickable {
                                    if (isPlaying) {
                                        exoPlayer?.pause()
                                    } else {
                                        exoPlayer?.play()
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "تشغيل/إيقاف",
                                tint = PureWhite,
                                modifier = Modifier.size(42.dp)
                            )
                        }
                    }

                    // Bottom Bar Overlay & Controls
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomStart)
                            .background(Color.Black.copy(alpha = 0.6f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Left side: Time or Live status
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(if (isPlaying) Color.Red else Color.Gray)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isLiveStream) "00:00 · 00:00" else formatMs(currentPositionMs) + " / " + formatMs(durationMs),
                                    color = PureWhite,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            // Right side controls: Fit, CC, Gear, Volume, Fullscreen
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                // Fit Mode Button ("Fit", "Fill", "Zoom", "16:9")
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color.White.copy(alpha = 0.2f))
                                        .clickable {
                                            val modes = FitMode.values()
                                            val nextIndex = (fitMode.ordinal + 1) % modes.size
                                            fitMode = modes[nextIndex]
                                        }
                                        .padding(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = fitMode.label,
                                        color = PureWhite,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                // Subtitles / Audio Tracks ("CC")
                                IconButton(
                                    onClick = { showAudioDialog = true },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ClosedCaption,
                                        contentDescription = "الترجمة والصوت",
                                        tint = PureWhite
                                    )
                                }

                                // Settings Gear Icon
                                IconButton(
                                    onClick = { showQualityDialog = true },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Settings,
                                        contentDescription = "جودة البث",
                                        tint = PureWhite
                                    )
                                }

                                // Mute / Unmute
                                IconButton(
                                    onClick = {
                                        isMuted = !isMuted
                                        exoPlayer?.volume = if (isMuted) 0f else 1f
                                    },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                                        contentDescription = "الصوت",
                                        tint = PureWhite
                                    )
                                }

                                // Fit / Aspect Ratio Expand
                                IconButton(
                                    onClick = {
                                        val modes = FitMode.values()
                                        val nextIndex = (fitMode.ordinal + 1) % modes.size
                                        fitMode = modes[nextIndex]
                                    },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Fullscreen,
                                        contentDescription = "ملء الشاشة",
                                        tint = PureWhite
                                    )
                                }
                            }
                        }

                        // Bottom Seekbar Line
                        LinearProgressIndicator(
                            progress = { if (durationMs > 0) currentPositionMs.toFloat() / durationMs.toFloat() else 1f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(3.dp),
                            color = BrightCyan,
                            trackColor = Color.White.copy(alpha = 0.3f)
                        )
                    }
                }
            }
        }
    }

    // Quality Selector Dialog
    if (showQualityDialog) {
        AlertDialog(
            onDismissRequest = { showQualityDialog = false },
            title = { Text("إعدادات جودة البث (HLS)", color = PureWhite, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    listOf("تلقائي (Auto / Adaptive)", "1080p FHD", "720p HD", "480p SD", "360p").forEach { quality ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedQuality = quality
                                    showQualityDialog = false
                                    Toast.makeText(context, "تم تحديد الجودة: $quality", Toast.LENGTH_SHORT).show()
                                }
                                .padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = quality,
                                color = if (selectedQuality == quality) BrightCyan else PureWhite,
                                fontWeight = if (selectedQuality == quality) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showQualityDialog = false }) {
                    Text("إغلاق", color = BrightCyan)
                }
            },
            containerColor = DeepBlack
        )
    }

    // Audio / CC Track Dialog
    if (showAudioDialog) {
        AlertDialog(
            onDismissRequest = { showAudioDialog = false },
            title = { Text("المسار الصوتي والترجمة", color = PureWhite, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    listOf("الصوت الافتراضي (التعليق العربي)", "الصوت الثاني (English)", "بدون ترجمة").forEach { track ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    showAudioDialog = false
                                    Toast.makeText(context, "تم اختيار: $track", Toast.LENGTH_SHORT).show()
                                }
                                .padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = track, color = PureWhite)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAudioDialog = false }) {
                    Text("إغلاق", color = BrightCyan)
                }
            },
            containerColor = DeepBlack
        )
    }
}

private fun formatMs(ms: Long): String {
    val totalSeconds = ms / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format(java.util.Locale.US, "%02d:%02d", minutes, seconds)
}
