package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.AdSettings
import com.example.data.Category
import com.example.data.Channel
import com.example.data.MainRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class UiState(
    val categories: List<Category> = emptyList(),
    val channels: List<Channel> = emptyList(),
    val filteredChannels: List<Channel> = emptyList(),
    val selectedCategoryId: Int? = null,
    val searchQuery: String = "",
    val isLoading: Boolean = true,
    val errorMessage: String? = null,
    val adSettings: List<AdSettings> = emptyList()
)

private data class RawData(
    val categories: List<Category>,
    val channels: List<Channel>,
    val ads: List<AdSettings>
)

private data class FilterState(
    val selectedCatId: Int?,
    val search: String
)

class MainViewModel(
    private val mainRepository: MainRepository
) : ViewModel() {

    class Factory(private val repository: MainRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return MainViewModel(repository) as T
        }
    }

    private val _categories = MutableStateFlow<List<Category>>(emptyList())
    private val _allChannels = MutableStateFlow<List<Channel>>(emptyList())
    private val _selectedCategoryId = MutableStateFlow<Int?>(null)
    private val _selectedChannel = MutableStateFlow<Channel?>(null)
    val selectedChannel: StateFlow<Channel?> = _selectedChannel
    private val _searchQuery = MutableStateFlow("")
    private val _isLoading = MutableStateFlow(true)
    private val _errorMessage = MutableStateFlow<String?>(null)
    private val _adSettings = MutableStateFlow<List<AdSettings>>(emptyList())

    private val _dataFlow = combine(_categories, _allChannels, _adSettings) { categories, channels, ads ->
        RawData(categories, channels, ads)
    }

    private val _filterFlow = combine(_selectedCategoryId, _searchQuery) { catId, search ->
        FilterState(catId, search)
    }

    private val _statusFlow = combine(_isLoading, _errorMessage) { loading, error ->
        Pair(loading, error)
    }

    val uiState: StateFlow<UiState> = combine(
        _dataFlow,
        _filterFlow,
        _statusFlow
    ) { data, filter, status ->
        val (loading, error) = status
        val filtered = data.channels.filter { channel ->
            val matchesCategory = if (filter.selectedCatId == null) {
                true
            } else {
                val selectedCat = data.categories.find { it.id == filter.selectedCatId }
                val catName = selectedCat?.name?.trim()

                val idMatches = channel.categoryId == filter.selectedCatId ||
                        (channel.altCatId != 0 && channel.altCatId == filter.selectedCatId)

                val nameMatches = !catName.isNullOrEmpty() && (
                        channel.categoryName?.trim().equals(catName, ignoreCase = true) ||
                        channel.catNameAlt?.trim().equals(catName, ignoreCase = true) ||
                        channel.categoryStr?.trim().equals(catName, ignoreCase = true)
                )

                idMatches || nameMatches
            }
            val matchesSearch = filter.search.isBlank() || channel.channelName.contains(filter.search, ignoreCase = true)
            matchesCategory && matchesSearch
        }

        UiState(
            categories = data.categories,
            channels = data.channels,
            filteredChannels = filtered,
            selectedCategoryId = filter.selectedCatId,
            searchQuery = filter.search,
            isLoading = loading,
            errorMessage = error,
            adSettings = data.ads
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = UiState()
    )

    init {
        loadData()
    }

    fun loadData() {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            try {
                val fetchedCategories = mainRepository.getCategories()
                val fetchedChannels = mainRepository.getChannels()
                val fetchedAds = mainRepository.getAdSettings()

                _categories.value = fetchedCategories
                _allChannels.value = fetchedChannels
                _adSettings.value = fetchedAds
            } catch (e: Exception) {
                _errorMessage.value = e.localizedMessage ?: "حدث خطأ أثناء تحميل القنوات"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun selectCategory(categoryId: Int?) {
        _selectedCategoryId.value = categoryId
    }

    fun selectChannel(channel: Channel) {
        _selectedChannel.value = channel
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun addCustomChannel(channelName: String, streamUrl: String, logoUrl: String? = null) {
        val trimmedUrl = streamUrl.trim()
        if (trimmedUrl.isBlank()) return
        val newChannel = Channel(
            id = (System.currentTimeMillis() % 1000000).toInt(),
            rawChannelName = channelName.ifBlank { "قناة مخصصة" },
            rawStreamUrl = trimmedUrl,
            logoUrl = logoUrl?.ifBlank { null }
        )
        _allChannels.value = listOf(newChannel) + _allChannels.value
    }
}
