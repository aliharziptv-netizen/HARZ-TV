package com.example.di

import com.example.data.MainRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.serializer.KotlinXSerializer
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    private const val FIREBASE_DB_URL = "https://harzlivesystem-default-rtdb.firebaseio.com"
    private const val FIREBASE_API_KEY = "AIzaSyAS1Uvd7IHB2g4cj7xuQy3G_nq-qBc6TX8"

    @Provides
    @Singleton
    fun provideJson(): Json {
        return Json {
            ignoreUnknownKeys = true
            coerceInputValues = true
            encodeDefaults = true
            explicitNulls = false
            isLenient = true
        }
    }

    @Provides
    @Singleton
    fun provideOkHttpClient(): OkHttpClient {
        return OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .addInterceptor(HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BODY
            })
            .build()
    }

    @Provides
    @Singleton
    fun provideSupabaseClient(json: Json): SupabaseClient {
        return createSupabaseClient("https://dummy.supabase.co", "dummy") {
            defaultSerializer = KotlinXSerializer(json)
            install(Postgrest)
        }
    }

    @Provides
    @Singleton
    fun provideMainRepository(
        okHttpClient: OkHttpClient,
        json: Json
    ): MainRepository {
        return MainRepository(
            okHttpClient = okHttpClient,
            json = json,
            firebaseDbUrl = FIREBASE_DB_URL,
            firebaseApiKey = FIREBASE_API_KEY
        )
    }
}

