package com.example

import android.os.Bundle
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.di.AppModule
import com.example.ui.MainViewModel
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PlayerScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.theme.HARZTVTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            HARZTVTheme {
                HarzTvAppNavigation()
            }
        }
    }
}

@Composable
fun HarzTvAppNavigation() {
    val navController = rememberNavController()

    val repository = remember {
        AppModule.provideMainRepository(
            okHttpClient = AppModule.provideOkHttpClient(),
            json = AppModule.provideJson()
        )
    }

    val viewModel: MainViewModel = viewModel(
        factory = MainViewModel.Factory(repository)
    )

    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    NavHost(
        navController = navController,
        startDestination = "splash"
    ) {
        // Splash Screen Route
        composable("splash") {
            SplashScreen(
                onNavigateToHome = {
                    navController.navigate("home") {
                        popUpTo("splash") { inclusive = true }
                    }
                }
            )
        }

        // Home Screen Route
        composable("home") {
            HomeScreen(
                uiState = uiState,
                onCategorySelected = { categoryId ->
                    viewModel.selectCategory(categoryId)
                },
                onSearchQueryChanged = { query ->
                    viewModel.updateSearchQuery(query)
                },
                onChannelClick = { channel ->
                    viewModel.selectChannel(channel)
                    navController.navigate("player")
                },
                onRefresh = {
                    viewModel.loadData()
                },
                onAddCustomChannel = { name, url, logo ->
                    viewModel.addCustomChannel(name, url, logo)
                }
            )
        }

        // Player Screen Route
        composable("player") {
            val selectedChannel by viewModel.selectedChannel.collectAsStateWithLifecycle()
            val streamUrl = selectedChannel?.streamUrl ?: ""
            val channelName = selectedChannel?.channelName ?: "قناة"

            PlayerScreen(
                streamUrl = streamUrl,
                channelName = channelName,
                onBack = {
                    if (navController.previousBackStackEntry != null) {
                        navController.popBackStack()
                    }
                }
            )
        }
    }
}

private fun safeEncode(value: String): String {
    if (value.isBlank()) return "empty"
    return try {
        java.net.URLEncoder.encode(value, "UTF-8")
    } catch (e: Exception) {
        try {
            Base64.encodeToString(value.toByteArray(Charsets.UTF_8), Base64.URL_SAFE or Base64.NO_WRAP)
        } catch (ex: Exception) {
            "empty"
        }
    }
}

private fun safeDecode(value: String): String {
    if (value == "empty" || value.isBlank()) return ""
    try {
        val decoded = java.net.URLDecoder.decode(value, "UTF-8")
        if (decoded.startsWith("http://") || decoded.startsWith("https://") || decoded.contains(".") || decoded.contains("/")) {
            return decoded
        }
    } catch (e: Exception) {
        // Fallback
    }
    try {
        val decodedBase64 = String(Base64.decode(value, Base64.URL_SAFE or Base64.NO_WRAP), Charsets.UTF_8)
        if (decodedBase64.isNotBlank()) {
            return decodedBase64
        }
    } catch (e: Exception) {
        // Fallback
    }
    return value
}
